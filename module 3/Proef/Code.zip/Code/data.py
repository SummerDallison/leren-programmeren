PROMPT_WELKOM = "Welkom bij Papi Gelato, je mag alle smaken kiezen zolang het maar vanille ijs is."
PROMPT_BOLLETJES = "Hoeveel bolletjes wilt u? "
PROMPT_KEUZE = "Wilt u deze {aantal} bolletje(s) in een hoorntje of een bakje? "
PROMPT_MEER = "Wilt u nog meer bestellen? (ja/nee) "

ERROR_ONBEKEND = "Sorry, dat snap ik niet..."
ERROR_BAKKEN = "Sorry, zulke grote bakken hebben we niet."

ANTWOORD_BAKJE = "Dan krijgt u van mij een bakje met {aantal} bolletjes."
ANTWOORD_HOORNTJE_BAKJE = "Hier is uw {keuze} met {aantal} bolletje(s)."
AFSLUITING = "Bedankt en tot ziens!"